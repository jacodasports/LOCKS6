(function(window, undefined) {
  var dictionary = {
    "10fa87a5-7738-421a-82bd-08e22fbd2e14": "[[NFL WEEKS]]",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "5e65f7de-4e8b-47c9-98ba-8a6e8e68c6e6": "NFL TEAMS",
    "4efdf82d-d5a9-4a6f-89b9-ef694975fa40": "CALCULATION",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);